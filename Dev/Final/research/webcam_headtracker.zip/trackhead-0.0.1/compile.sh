
PKG_CONFIG_PATH="$PKG_CONFIG_PATH:/usr/local/lib/pkgconfig"

g++ -o headtracking -I/home/andy/download/irrlicht-1.4/include headtracking.cpp `pkg-config opencv --cflags --libs` -L/home/andy/download/irrlicht-1.4/lib/Linux  -lIrrlicht -lGL -lX11 -lXxf86vm -lXext

