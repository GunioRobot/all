
/*
 * Trackhead 0.0.1 alpha
 * Copyright (C) 2008 Andreas Burtzlaff
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

/*
 * Trackhead 0.0.1 alpha
 * Glad this works :-)
 * The projection matrix for a arbitrary frustum projection was determined 
 * by trial and error using the original opengl version as a basis.
 * I have no idea why the original opengl version doesn't work properly.
 * The projection still behaves strangely in certain situations, but with 
 * screenCenterNormal parallel to the z direction it works as expected.
 *
 * Head tracking:
 * Use two bright leds with fixed distance and a webcam, possibly with 
 * sunglasses or such as filter.
 * Calibrate the headtracking by measuring the distance in pixels between the
 * bright spots at different distances (measured in cm) and make a regression.
 * Insert the formula in function translate_distance_from_webcam
 * 
 * The VR setup:
 * Look at the beginning of main().
 *
 * Feel free to contact me, if you notice anything noteworthy :-).
 * andy13 at gmx dot net
 *
 */
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <stdio.h>
#include <math.h>

#include <irrlicht.h>
#include <matrix4.h>

#define SMOOTHCOUNT 5
#define NOISE_THRESHOLD 8.0

#define DETECTION_MODE DETECT_MAX_DISTANCE
#define DETECT_COLOR 1
#define DETECT_MAX_DISTANCE 2

#define TOLERANCE 10
#define MIN_DISTANCE 15

#define SCREEN_WIDTH 43
// translate the distance of the two bright spots in the webcam image in pixel
// into the distance from the webcam in cm ( determined by experiment ) 
double translate_distance_from_webcam( double distance ) {
  return 7685*pow( distance , -1.033 );
}

//#define ROOM
//#define WORLD
#define SONIC
using namespace irr;

using namespace core;
using namespace scene;
using namespace video;
using namespace io;
using namespace gui;

vector3df positions[] = {vector3df( 0,0,0 ),vector3df( 3,2,-10),vector3df( -2,-1,-70), vector3df( 3, 2, -60),
			 vector3df( -2,5, 18), vector3df( 6,-4,25), vector3df( -9,6, -100) };
int positions_size = sizeof( positions ) / sizeof( vector3df );


int max( int a, int b ) {
  if( a < b )
    return b;
  else
    return a;
}
int min( int a, int b ) {
  if( a < b )
    return a;
  else
    return b;
}
double signum(double x) {
  if( x > 0 )
    1;
  else if( x < 0 )
    -1;
  else
    0;
}

void printVector(char* s, vector3df v ) {
  printf("%s ( %g,%g,%g )\n", s, v.X ,v.Y ,v.Z );
}

void printMatrix(char* s, matrix4 m ) {
  int row,col;
  printf("%s : \n", s );
  for( row = 0 ; row < 4 ; row++ ) {
    printf("( ");
    for( col = 0 ; col < 4; col++ ) 
      printf(" %g   ", m[col*4 + row ] );
    printf("( \n");
  }
  printf("\n");
}

// copied from mesa opengl implementation (_math_matrix_frustum in math/m_matrix.c)

matrix4 make_projection_matrix( float left, float right,
			float bottom, float top,
			float nearval, float farval )
{
   float x, y, a, b, c, d;
   float m[16];

   x = (2.0*nearval) / (right-left);
   y = (2.0*nearval) / (top-bottom);
   a = (right+left) / (right-left);
   b = (top+bottom) / (top-bottom);
   c = -(farval+nearval) / ( farval-nearval);
   d = -(2.0*farval*nearval) / (farval-nearval);

   matrix4 M;

   m[0] = x;     
   m[1] = 0.0F;  
   m[2] = 0.0F;  
   m[3] = 0.0F;  
   
   m[4] = 0.0F;  
   m[5] = y;     
   m[6] = 0.0F;  
   m[7] = 0.0F;  

   m[8] = a;      
   m[9] = b;      
   m[10] = -c;   // original Opengl +c     
   m[11] = 1.0F; // original Opengl -1.0F  

   m[12] = 0.0F;
   m[13] = 0.0F;
   m[14] = d;
   m[15] = 0.0F;
   
   M.setM(m);
   return M;
}


bool quit = false;
vector3df screenCenterNormal;
vector3df screenCenter;

class EventReceiver : public IEventReceiver
{
 public:
  virtual bool OnEvent(const SEvent& event)
  {
    if (event.EventType == EET_KEY_INPUT_EVENT)
      {
	if(event.KeyInput.PressedDown)
	  {
            if(event.KeyInput.Key == KEY_KEY_Q)
	      {
		quit = true;
		return true;
	      } 
	    else if( event.KeyInput.Key == KEY_KEY_D )
	      {
		screenCenterNormal.rotateXZBy( PI/2.0, vector3df(0,0,0));
	      }
	    else if( event.KeyInput.Key == KEY_KEY_A )
	      {
		screenCenterNormal.rotateXZBy( -PI/2.0, vector3df(0,0,0));
	      }
	    else if( event.KeyInput.Key == KEY_KEY_W )
	      {
		screenCenter += screenCenterNormal * 6.0;
	      }
	    else if( event.KeyInput.Key == KEY_KEY_S )
	      {
		screenCenter -= screenCenterNormal * 6.0;
	      }
	  }
	
      }
    return false;
  }
};

// A Simple Camera Capture Framework
int main(int argc, char ** argv) {

  int delay = 0;

  double param1, param2;
  if (argc >= 3 ){
    param1 = atoi( argv[1] );
    param2 = atoi( argv[2] );
  } else {
     param1 = 180;
     param2 = 40;
  }
  
  // the center of the screen in the virtual world ( irrlichts _LEFT_HANDED_ coordinate system )
  screenCenter = vector3df( 0,0,0 );

  // the vector pointing from the screenCenter in the direction of the object to view in the virtual world 
  // ( irrlichts _LEFT_HANDED_ coordinate system )
  screenCenterNormal = vector3df(0,0,1).normalize();
  
  // vector pointing upwards from the screenCenter in the virtual world ( irrlichts _LEFT_HANDED_ coordinate system )
  vector3df screenUpVector = vector3df( 0,-1,0 );

  // the width of the screen in cm
  double screenHeight = 31;

  //vector3df cameraUpVector = vector3df( 0,1,0 ).normalize();

  /* --- real world setup --- */
  // The real world setup has the middle of the screen as reference point.
  // The direction normal to the screen in direction to the user is defined as (positive) z axis
  // The left to right axis is defined as the x axis
  // The down to up axis is defined as the y axis

  // the position of the webcam with reference to the middle of the monitor in cm 
  vector3df webcamPosition = vector3df( 0,21,0 );
  
  // the direction of the webcam
  vector3df webcamDirection = vector3df(0,0,1).normalize();
  
  // the up direction of the webcam
  vector3df webcamUpVector = vector3df(0,1,0).normalize();

  // units per cm 
  double scale = 1.0;

  double scale_model = 1.0;
  
  webcamUpVector = webcamDirection.crossProduct( webcamUpVector.crossProduct( webcamDirection ) ); 

  

  CvCapture* capture = cvCaptureFromCAM( CV_CAP_ANY );
  if( !capture ) {
    fprintf( stderr, "ERROR: capture is NULL \n" );
    getchar();
    return -1;
  }
  /* ---------------------- initialize irrlicht --------------*/
  EventReceiver receiver; 
  
  IrrlichtDevice *device =
    createDevice(EDT_OPENGL, core::dimension2d<s32>(1024, 768),32, true, false, false, &receiver, IRRLICHT_SDK_VERSION);


  device->setWindowCaption(L"Head tracking demo");


  IVideoDriver* driver = device->getVideoDriver();
  ISceneManager* smgr = device->getSceneManager();
  IGUIEnvironment* guienv = device->getGUIEnvironment();
  
  core::matrix4 identity;
  driver->setTransform(video::ETS_WORLD, identity);
  driver->setTransform(video::ETS_VIEW, identity); 

  

  smgr->addLightSceneNode();
  smgr->addLightSceneNode(0, core::vector3df(50,50,-100), video::SColorf(1.0f,1.0f,1.0f),20000);


  //IAnimatedMesh* mesh = smgr->getMesh("/home/andy/download/irrlicht-1.4/media/room.3ds");
  #ifdef ROOM
  IAnimatedMesh* mesh_room = smgr->getMesh("3dmodels/room.3ds");
  
  IAnimatedMeshSceneNode* node_room = smgr->addAnimatedMeshSceneNode( mesh_room,0,-1, vector3df(-0.5* screenWidth * scale ,-10,-10),vector3df(0,0,0),vector3df( 2,2,2 ) );
  

#else
#ifdef WORLD
  scale = 6.0;
  device->getFileSystem()->addZipFileArchive("3dmodels/map-20kdm2.pk3");

  scene::IAnimatedMesh* mesh = smgr->getMesh("20kdm2.bsp");
  scene::ISceneNode* node = 0;
  
  if (mesh)
    node = smgr->addOctTreeSceneNode(mesh->getMesh(0), 0, -1, 128);
  
  if (node)
    node->setPosition(core::vector3df(-1300,-144,-1249));

#else
#ifdef SONIC
  IAnimatedMesh* mesh_sonic = smgr->getMesh("3dmodels/sonic.3ds");
  IAnimatedMesh* mesh_angel = smgr->getMesh("3dmodels/cherub06.3ds");
  
  int i;
  for( i = 0 ; i < positions_size ; i++ )
    smgr->addAnimatedMeshSceneNode( mesh_sonic,0,-1, positions[i],vector3df(0,0,0),vector3df( scale_model,scale_model,scale_model ) );
#endif
#endif
#endif
  //CCameraSceneNodeCustom* camera = new CCameraSceneNodeCustom(0, smgr, -1);
  //smgr->setActiveCamera( camera );

  ICameraSceneNode* camera = smgr->addCameraSceneNode(0, vector3df(0,30,0), vector3df(0,5,0));

  /* ---------------------- end initialize irrlicht --------------*/
  
  /*printf("IPL_DEPTH_8U: %u\n", IPL_DEPTH_8U);
    printf("IPL_DEPTH_8S: %u\n", IPL_DEPTH_8S);
    printf("IPL_DEPTH_16U: %u\n",IPL_DEPTH_16U);
    printf("IPL_DEPTH_16S: %u\n",IPL_DEPTH_16S);
    printf("IPL_DEPTH_32S: %u\n",IPL_DEPTH_32S);
    printf("IPL_DEPTH_32F: %u\n",IPL_DEPTH_32F);
    printf("IPL_DEPTH_64F: %u\n",IPL_DEPTH_64F);
    
    printf("Image depth: %i", frame->depth );
    */

  float curX;
  float curY;

  // Show the image captured from the camera in the window and repeat
  while( !quit && device->run() ) {
    // Get one frame
    IplImage* frame = cvQueryFrame( capture );
    if( !frame ) {
      fprintf( stderr, "ERROR: frame is null...\n" );
      getchar();
      break;
    }

    
    //IplImage* gray = cvCreateImage( cvGetSize( frame ), 8, 1 );
    //CvMemStorage* storage = cvCreateMemStorage(0);
    //cvCvtColor( frame, gray, CV_BGR2GRAY );

    CvSize size = cvGetSize( frame );

    

    int x,y;

    
    int maxA, maxR, maxG, maxB;
    maxA = maxR = maxG = maxB = 0;
    CvPoint pMaxA = cvPoint(0,0);
    CvPoint pMaxR = cvPoint(0,0);
    CvPoint pMaxG = cvPoint(0,0);
    CvPoint pMaxB = cvPoint(0,0);
    pMaxR.x = pMaxR.y =0;
    
    uchar* base;
    int r,g,b;
    for( x = 0 ; x < size.width ; x++ ) {
      for( y = 0 ; y < size.height ; y++ ) {
	base = ((uchar*)(frame->imageData + frame->widthStep*y));
	r = base[x*3+2];
	g = base[x*3+1];
	b = base[x*3];
	if( r + g + b > maxA ) {
	  maxA = r + g + b; pMaxA.x = x; pMaxA.y = y;
	}
	if( b > maxB ) {
	  maxB = b; pMaxB.x = x; pMaxB.y = y;
	}
	if( g > maxG ) {
	  maxG = g; pMaxG.x = x; pMaxG.y = y;
	}
	if( r > maxR ) {
	  maxR = r; pMaxR.x = x; pMaxR.y = y;
	}
      }
    }
    //printf("pMaxR: %u , %u\n",pMaxR.x,pMaxR.y);
    //printf("pMaxG: %u , %u\n",pMaxG.x,pMaxG.y);
    //printf("pMaxB: %u , %u\n",pMaxB.x,pMaxB.y);
    //printf("MaxR: %i", maxR);
    //printf("MaxG: %i", maxG);
    //printf("MaxB: %i", maxB);
    
    
    //}
    
    // determine max distance in x direction of all points with max intensity (r,g,b)
    int minXR,minXG,minXB,maxXR,maxXG,maxXB;
    int maxDistXR,maxDistXG,maxDistXB, maxX, minX;
    int minYR,minYG,minYB,maxYR,maxYG,maxYB;
    int maxDistYR,maxDistYG,maxDistYB, maxY, minY;
    int tolerance = TOLERANCE;
    do {
      minXR = minXG = minXB = 320;
      maxXR = maxXG = maxXB = 0;
      minYR = minYG = minYB = 240;
      maxYR = maxYG = maxYB = 0;
      for( x = 0 ; x < size.width ; x++ ) {
	for( y = 0 ; y < size.height ; y++ ) {
	  base = ((uchar*)(frame->imageData + frame->widthStep*y));
	  r = base[x*3+2];
	  g = base[x*3+1];
	  b = base[x*3];
	  if( r >= maxR - tolerance ) {
	    if( x < minXR )
	      minXR = x;
	    else if( x > maxXR )
	      maxXR = x;
	    if( y < minYR )
	      minYR = y;
	    else if( y > maxYR )
	      maxYR = y;
	  }
	  if( g >= maxG - tolerance ) {
	    if( x < minXG )
	      minXG = x;
	    else if( x > maxXG )
	      maxXG = x;
	    if( y < minYG )
	      minYG = y;
	    else if( y > maxYG )
	      maxYG = y;
	  }
	  if( b >= maxB - tolerance ) {
	    if( x < minXB )
	      minXB = x;
	    else if( x > maxXB )
	      maxXB = x;
	    if( y < minYB )
	      minYB = y;
	    else if( y > maxYB )
	      maxYB = y;
	  }
	}
      }
      
      maxDistXR = maxXR - minXR;
      maxDistXG = maxXG - minXG;
      maxDistXB = maxXB - minXB;

      maxDistYR = maxYR - minYR;
      maxDistYG = maxYG - minYG;
      maxDistYB = maxYB - minYB;


      maxX = max( max( maxXR, maxXG), maxXB );
      minX = min( min( minXR, minXG), minXB );

      maxY = max( max( maxYR, maxYG), maxYB );
      minY = min( min( minYR, minYG), minYB );

      

    } while( (double) abs(maxX - minX) < MIN_DISTANCE && !(tolerance++) );
    double center_x; double center_y; double distance;
    double gamma = 0;
    
    if( DETECTION_MODE == DETECT_MAX_DISTANCE ) {
      
      //cvLine( frame, cvPoint( maxXR ,0), cvPoint(maxXR, 240), CV_RGB(255,0,0), 1, CV_AA, 0);
      //cvLine( frame, cvPoint( maxXG ,0), cvPoint(maxXG, 240), CV_RGB(0,255,0), 1, CV_AA, 0);
      //cvLine( frame, cvPoint( maxXB ,0), cvPoint(maxXB, 240), CV_RGB(0,0,255), 1, CV_AA, 0);
      //cvLine( frame, cvPoint( maxX, 0 ), cvPoint(maxX,  240), CV_RGB(255,255,255), 1, CV_AA, 0);
      //cvLine( frame, cvPoint( minX, 0 ), cvPoint(minX,  240), CV_RGB(255,255,255), 1, CV_AA, 0);
      
      distance = (double) abs(maxX - minX);

      center_x = (double) (maxX + minX ) / 2.0;
      center_y = (double) (maxY + minY ) / 2.0;

      printf("(maxY,minY) : (%i,%i)\n",maxY,minY);

      gamma = atan( (double) (maxY - minY) / (double) (maxX - minX) );

    }

    //printf("Distance: %g\n", distance);
    // determine distance d in cm from display (the formula was determined by experiment)
    //double d_from_webcam = 7685*pow( distance , -1.033 );
    double d_from_webcam = translate_distance_from_webcam( distance );
    //printf("d_from_webcam / cm : %g\n", d_from_webcam );
    

    //printf("rotation gamma: %g\n", gamma);
    //printf("tan( gamma ): %g\n", tan( gamma) );

    // determine angle phi (x-direction) and theta(y-direction) from center
    double phi_webcam =   asin( ( ( 160 - center_x ) * 2.0/23.0 ) / 30.0 );
    double theta_webcam = asin( ( ( 120 - center_y ) * 2.0/23.0 ) / 30.0 );
    
    // the position of the head with reference to the middle of the monitor
    vector3df headPosition = webcamPosition 
      + ( (
	   webcamDirection +
	   (webcamDirection.crossProduct( webcamUpVector ) *(-1) * tan( phi_webcam ) )
	   + (webcamUpVector * tan( theta_webcam )) ).normalize() * d_from_webcam );
    
    //printVector( "Head position: ", headPosition);

    /* --- calculate values with reference to the middle of the screen (0,0,0) */

    double d = headPosition.getLength();
    
    double d_perp = fabs( headPosition.dotProduct( vector3df( 0,0,-1 ) ) );

    double phi = asin( headPosition.X / d ); // phi_webcam; 
    double theta = asin( headPosition.Y / d );
    
      
    /* -----------------------------------  BEGIN update 3d view accordingly ----------------------*/
    
    //driver->beginScene(true, true, SColor(255,100,101,140));
    driver->beginScene(true, true, SColor(0,0,0,0));

    //printf("phi (Grad): %g\n",phi / (2*PI) * 360.0);
    // using distance d / cm from screen and angle phi and theta
    // note that the camera is in Irrlichts _LEFT_HANDED_COORDINATE_SYSTEM_
    //
    vector3df cameraPosition = screenCenter - (screenCenterNormal * ( d_perp * scale )) + (
      screenUpVector.crossProduct( screenCenterNormal ) * (-1) *  d_perp *scale * tan( phi ) ) +
      (screenUpVector * (-1) * d_perp  * scale * tan( theta ));
    
    //printf("Camera position: ( %g, %g, %g )\n",cameraPosition.X,cameraPosition.Y,cameraPosition.Z);
    
    camera->setPosition( cameraPosition );

    camera->setTarget( screenCenter + cameraPosition - ( cameraPosition.dotProduct( screenCenterNormal ) * screenCenterNormal) );

    float nearPlane = 0.05;//d_perp * scale - 20;
    float farPlane = d_perp * scale + 100000;

    //matrix4 projectionMatrix = camera->getProjectionMatrix();

    double x_shift = cameraPosition.dotProduct( screenUpVector.crossProduct( screenCenterNormal ) );
    double y_shift = cameraPosition.dotProduct( screenUpVector );

    matrix4 projectionMatrix = make_projection_matrix( nearPlane*( -0.5 * SCREEN_WIDTH * scale - x_shift ) / (d_perp * scale),
    						       nearPlane*( 0.5 * SCREEN_WIDTH * scale -  x_shift ) / (d_perp * scale),
    						       nearPlane*( -0.5 * screenHeight * scale - y_shift ) / (d_perp * scale) ,
    						       nearPlane*( 0.5 * screenHeight * scale - y_shift  ) / (d_perp* scale),
    						       nearPlane, farPlane);

    //printMatrix( "Projection matrix", projectionMatrix );
    
    //matrix4 projectionMatrixTransposed;
    //projectionMatrix.getTransposed( projectionMatrixTransposed );

    camera->setProjectionMatrix( projectionMatrix );


    //printMatrix( "Projection matrix from camera: ",camera->getProjectionMatrix() );

    //printMatrix( "View matrix from camera: " , camera->getViewMatrix() );

    //const SViewFrustum* frustum = camera->getViewFrustum();

    //double scaleFactor = d_perp * scale / farPlane;
    //vector3df v = frustum->getFarLeftDown();
    //printf("Far left down: ( %g,%g,%g )\n", v.X * scaleFactor,v.Y *scaleFactor ,v.Z );
    
    //v = frustum->getFarLeftUp();
    //printf("Far left up: ( %g,%g,%g )\n", v.X * scaleFactor,v.Y * scaleFactor,v.Z );

    //v = frustum->getFarRightUp();
    //printf("Far right up: ( %g,%g,%g )\n", v.X * scaleFactor,v.Y* scaleFactor,v.Z );
    //v = frustum->getFarRightDown();
    //printf("Far right down: ( %g,%g,%g )\n", v.X* scaleFactor,v.Y* scaleFactor,v.Z );

    #ifdef SONIC

    int i;
    int grid_x = 8;
    int grid_y = 8;
    int grid_z = 20;
    vector3df grid_target = vector3df( 0,0,1e5 );
    SColor grid_color = SColor(0,100,0,0);
    //draw a grid
    for( i = 0 ; i < SCREEN_WIDTH / 2.0 * scale ; i+= grid_x ) {
      driver->draw3DLine( vector3df( i , -screenHeight / 2.0 * scale, 0),
			  grid_target, grid_color );
      driver->draw3DLine( vector3df( -i , -screenHeight / 2.0 * scale, 0),
			  grid_target, grid_color );
      driver->draw3DLine( vector3df( i , screenHeight / 2.0 * scale, 0),
			  grid_target, grid_color );
      driver->draw3DLine( vector3df( -i , screenHeight / 2.0 * scale, 0),
			  grid_target, grid_color );
    }
    for( i = 0 ; i < screenHeight / 2.0 * scale ; i+= grid_y ) {
      driver->draw3DLine( vector3df( -SCREEN_WIDTH / 2.0 * scale, i, 0),
			  grid_target, grid_color );
      driver->draw3DLine( vector3df( -SCREEN_WIDTH / 2.0 * scale, -i, 0),
			  grid_target, grid_color );
      driver->draw3DLine( vector3df( SCREEN_WIDTH / 2.0 * scale, i, 0),
			  grid_target, grid_color );
      driver->draw3DLine( vector3df( SCREEN_WIDTH / 2.0 * scale, -i, 0),
			  grid_target, grid_color );
    }
    for( i = 0 ; i < 1000 ; i += grid_z ) {
      driver->draw3DLine( vector3df( -SCREEN_WIDTH / 2.0 * scale, -screenHeight / 2.0 * scale, i ),
			  vector3df(  SCREEN_WIDTH / 2.0 * scale, -screenHeight / 2.0 * scale, i ), grid_color );
      driver->draw3DLine( vector3df( -SCREEN_WIDTH / 2.0 * scale,  screenHeight / 2.0 * scale, i ),
			  vector3df(  SCREEN_WIDTH / 2.0 * scale,  screenHeight / 2.0 * scale, i ), grid_color );
      driver->draw3DLine( vector3df( -SCREEN_WIDTH / 2.0 * scale, -screenHeight / 2.0 * scale, i ),
			  vector3df( -SCREEN_WIDTH / 2.0 * scale,  screenHeight / 2.0 * scale, i ), grid_color );
      driver->draw3DLine( vector3df(  SCREEN_WIDTH / 2.0 * scale, -screenHeight / 2.0 * scale, i ),
			  vector3df(  SCREEN_WIDTH / 2.0 * scale,  screenHeight / 2.0 * scale, i ), grid_color );
      
    }

    for( i = 0 ; i < positions_size ; i++ ) {
      driver->draw3DLine( positions[i] , screenCenter + ( screenCenterNormal * 100000.0) ); 
      //driver->draw3DLine( vector3df(0,0,0), vector3df(0,0,10000 ) ); 
      //driver->draw3DLine( vector3df(-100,0,0), vector3df( 100,0,0 ) );
    }
    
    #endif
    smgr->drawAll();
    
    driver->endScene();
    
    /* ----------------------------------- END update 3d view accordingly --------------------------*/
  }

  // Release the capture device housekeeping
  cvReleaseCapture( &capture );
  
  device->drop();
  return 0;
}
